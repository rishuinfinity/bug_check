
'use strict';

const {Gtk,Adw,Gio,GLib,Gdk,GdkPixbuf}  = imports.gi;
const ExtensionUtils = imports.misc.extensionUtils;
const Me             = ExtensionUtils.getCurrentExtension();

function init(){
}

function fillPreferencesWindow(window){
    window.set_default_size(400, 100);
    let builder = Gtk.Builder.new();
    const mySetting = ExtensionUtils.getSettings('org.gnome.shell.extensions.test');
    const page = new Adw.PreferencesPage();
    const group = new Adw.PreferencesGroup();
    page.add(group);
    let row = new Adw.ActionRow({ title: 'Show Extension Indicator' });
    group.add(row);
    let label = new Gtk.Label({ label: mySetting.get_string("val")});
    //mySetting.set_string("val","value");
    row.add_suffix(label);
    
    let randint = String(Math.random()); // This would show if it is a different listener or same
    mySetting.connect("changed::val", () => {
        log(randint + " " + mySetting.get_string("val"));
        label.label = mySetting.get_string("val");
        
    });
    
    window.add(page);
}


